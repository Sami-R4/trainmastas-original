<?php

// Create connection
// $trainmastas_conn = new mysqli('localhost', 'root', '', 'trainmastas_users');
// $trainmastas_conn = new mysqli('localhost', 'root', '', 'trainmastas_courses');
// $trainmastas_conn = new mysqli('localhost', 'root', '', 'trainmastas_payments');

$trainmastas_conn = new mysqli('localhost', 'u534990407_ngoupayou', 'Afriquemedia@12', 'u534990407_trainmastas_us');
$trainmastas_conn = new mysqli('localhost', 'u534990407_ngoupayouhabil', 'Afriquemedia@12', 'u534990407_trainmastas_co');
$trainmastas_conn = new mysqli('localhost', 'u534990407_ngoupayou1', 'Afriquemedia@12', 'u534990407_trainmastas_pa');
