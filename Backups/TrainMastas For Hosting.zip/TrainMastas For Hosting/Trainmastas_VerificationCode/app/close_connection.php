<?php
$trainmastas_conn->close();
$trainmastas_conn->close();
$trainmastas_conn->close();
