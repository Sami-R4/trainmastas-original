<?php

if (isset($_SESSION['UID'])) {
    $UID = $_SESSION['UID'];
    // Update base query for logged-in users with dynamic filters
    $base_query = "SELECT cp.course_ID, cp.Title, cp.Cover_image, cp.Cost, cp.Date, u.Name AS Creator_Name, 
    IFNULL(AVG(cf.Rate), '') AS Avg_Rate, COUNT(CASE WHEN cf.Rate IS NOT NULL THEN 1 ELSE NULL END) AS Total_Rates
    FROM course AS cp LEFT JOIN course_scope AS cs ON cp.course_ID = cs.course_ID
    LEFT JOIN user AS u ON cp.user_ID = u.user_ID LEFT JOIN course_feedback AS 
    cf ON cp.course_ID = cf.course_ID WHERE cp.action = 'n' AND cp.user_ID != ? ";


    $user_fields = [];
    $user_query = "SELECT `Field` FROM `fields` WHERE `user_ID` = ?";
    $user_stmt = $trainmastas_conn->prepare($user_query);
    $user_stmt->bind_param("s", $UID);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    while ($row = $user_result->fetch_assoc()) {
        $user_fields[] = $row['Field'];
    }
    $user_stmt->close();

    // Add category filter
    if (!empty($category_Search)) {
        $base_query .= " $category_Search";
    }

    // Add course type filter
    if (!empty($type_Search)) {
        $base_query .= " $type_Search";
    }

    // Add user preferences conditions
    if (!empty($user_fields)) {
        $field_conditions = [];
        foreach ($user_fields as $field) {
            $field_conditions[] = "(cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?)";
        }
        $fields_condition = implode(' OR ', $field_conditions);
        $base_query .= " AND ($fields_condition) ";
    }

    // Add grouping, sorting, and limits
    $base_query .= "GROUP BY cp.course_ID ORDER BY cp.Date $period_Search, Avg_Rate DESC LIMIT ?, ?";

    // Count query for total courses with filters
    $count_query = "SELECT COUNT(DISTINCT cp.course_ID) FROM course AS cp LEFT 
    JOIN course_scope AS cs ON cp.course_ID = cs.course_ID WHERE cp.action = 'n' AND cp.user_ID != ?";

    // Add filters to count query
    if (!empty($category_Search)) {
        $count_query .= " $category_Search";
    }
    if (!empty($type_Search)) {
        $count_query .= " $type_Search";
    }
    if (!empty($user_fields)) {
        $count_query .= " AND ($fields_condition) ";
    }

    // Prepare query parameters
    $query_params = [];
    $param_types = '';


    // Add category parameters
    if (isset($categories)) {
        foreach ($categories as $cat) {
            $query_params[] = $cat;
            $param_types .= "s";
        }
    }

    // Add user preferences
    foreach ($user_fields as $field) {
        $query_params[] = "%$field%";
        $query_params[] = "%$field%";
        $query_params[] = "%$field%";
        $param_types .= "sss";
    }

    $query_params[] = $UID; // Start with the UID
    $param_types .= "s"; // UID type

    // Prepare and execute the total count query
    $total_stmt = $trainmastas_conn->prepare($count_query);
    // echo "Type: $param_types \n\n";
    // echo print_r($query_params);
    // echo ($count_query);
    $total_stmt->bind_param($param_types, ...$query_params);
    $total_stmt->execute();
    $total_result = $total_stmt->get_result();
    $total_logged_in = $total_result->fetch_row()[0];

    // Add pagination parameters
    $query_params[] = $start;
    $query_params[] = $limit;
    $param_types .= "ii";
    // Prepare and execute the main query
    $stmt = $trainmastas_conn->prepare($base_query);
    $stmt->bind_param($param_types, ...$query_params);
    // echo ($base_query);
}
"SELECT cp.course_ID, cp.Title, cp.Cover_image, cp.Cost, cp.Date, u.Name AS Creator_Name, 
        IFNULL(AVG(cf.Rate), '') AS Avg_Rate, COUNT(CASE WHEN cf.Rate IS NOT NULL THEN 1 ELSE NULL END) AS Total_Rates
        CASE WHEN ( ((cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?) OR (cs.Scope LIKE ? OR cp.Category LIKE ? OR cp.Title LIKE ?)) ) THEN 1 ELSE 0 END AS MatchesPreference FROM course AS cp LEFT JOIN course_scope AS cs ON cp.course_ID = cs.course_ID
        LEFT JOIN user AS u ON cp.user_ID = u.user_ID LEFT JOIN course_feedback AS 
        cf ON cp.course_ID = cf.course_ID WHERE cp.action = 'n' AND cp.user_ID != ?   AND ( cp.Cost = 0) GROUP BY cp.course_ID ORDER BY cp.Date DESC, Avg_Rate DESC LIMIT ?, ?<br/>
";
