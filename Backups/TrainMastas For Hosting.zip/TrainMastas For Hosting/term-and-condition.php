<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="32x32" href="./image/logo.png">

    <script src="js/jquery.js"></script>
    <script src="js/session_checker.js"></script>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/owl.css">
    <link href="css/select2.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/header.css">
    <script src="js/bootstrap.js"></script>
    <title>Terms & Conditions - TrainMastas</title>
    <style>
        @media (max-width: 991px) {
            .btn-modified {
                width: 95%;
                margin-left: 2.5% !important;
                margin-right: 2.5% !important;
            }



            .Welcome-image-cover {
                padding-top: 80px !important;
            }

        }

        @media (min-width: 991px) and (max-width:992px) {
            .Welcome-image-cover {
                padding-top: 77px !important;
            }

        }

        @media (max-width: 575px) {
            .centralized-footer {
                text-align: center;
            }

        }


        .dropdown-item:hover {
            background-color: #38b6ff !important;
        }


        nav {
            z-index: 999;
            background-color: rgb(18, 58, 83);
        }

        a {
            text-decoration: none;
        }

        .nav-link {
            font-size: 14px;
        }

        @media (min-width:992px) {
            .mt-md-7 {
                margin-top: 15vh;
            }

            .mb-md-7 {
                margin-bottom: 11vh;
            }

        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php
    include "navbar.php";
    ?>
    <div class="container" style="padding-top:18vh;">
        <div class="col-12 col-md-10 mx-auto">
            <h2 class="text-muted text-center" style="margin-bottom:7vh">TrainMastas Terms & Conditions</h2>

            <p class="fs-6 fw-normal">
                Welcome to TrainMastas – your YouTube-powered learning platform. These Terms and Conditions govern your access to and use
                of TrainMastas, an independent educational company committed to providing engaging, exam-oriented courses online. By using our services as a student or course creator, you agree to comply with the following terms.
            </p>

            <ol class="mx-5 fs-6 fw-normal">

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Account Registration and Access</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users must register with accurate and complete information.</li>
                        <li>Each user is responsible for maintaining the security of their account credentials.</li>
                        <li>TrainMastas may restrict or revoke access to users found violating these terms or misusing the platform.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Course Enrollment and Completion</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users may enroll in both free and premium courses created by instructors on the platform.</li>
                        <li>Premium courses always include an exam and come with a certificate automatically downloadable upon completion.</li>
                        <li>Free courses may include an exam. If a user completes such a course with an exam, they can purchase a certificate.</li>
                        <li>Certificates are only issued for courses that include an exam.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Wallet, Payments, and Withdrawals</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users can add money to their wallet to pay for premium courses and certificates.</li>
                        <li>Course creators earn revenue from paid enrollments and can request withdrawals.</li>
                        <li>All transactions are handled securely through trusted third-party providers.</li>
                        <li>TrainMastas does not store sensitive payment data on its servers.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Course Withdrawal and Refund Policy</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users can withdraw from any course at any time, except after course completion.</li>
                        <li>If a user withdraws before reaching Module 2, they may be eligible for a refund.</li>
                        <li>If a user withdraws after Module 2, no refund will be issued, but withdrawal is still possible.</li>
                        <li>Once a course is completed and a certificate is issued, withdrawal and refunds are no longer available.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Course Content and Ownership</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Course creators retain full ownership of their content.</li>
                        <li>By publishing a course, creators grant TrainMastas a non-exclusive right to host, display, and promote their content.</li>
                        <li>TrainMastas reserves the right to remove any course or content that violates legal rights or platform guidelines.</li>
                        <li>Plagiarized, offensive, or fraudulent content will lead to removal and possible account termination.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Code of Conduct</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users must act respectfully and professionally on the platform at all times.</li>
                        <li>Hate speech, harassment, fraud, and illegal activity are strictly prohibited.</li>
                        <li>Cheating in exams or falsifying results is not tolerated and may lead to a ban.</li>
                        <li>TrainMastas retains the right to ban, suspend, or delete any user account or course for malicious activity without prior notice.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Security and Data Protection</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>User data is secured using modern encryption and safety protocols.</li>
                        <li>Passwords are stored securely and not accessible by platform administrators.</li>
                        <li>Users are advised not to share their login details with others.</li>
                        <li>Review our <a href="/privacy-policy" class="text-decoration-underline">Privacy Policy</a> for more on data handling practices.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Account Deletion and Termination</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>Users may request account deletion at any time by contacting support.</li>
                        <li>Accounts may be suspended or permanently deleted for breaching these Terms & Conditions.</li>
                        <li>Repeat violations by course creators may result in a permanent ban from the platform.</li>
                    </ul>
                </li>

                <li class="fw-semibold mb-4">
                    <p class="fs-6 my-3">Changes to Terms</p>
                    <ul class="ms-3" style="list-style-type:decimal;">
                        <li>TrainMastas reserves the right to modify or update these Terms & Conditions at any time.</li>
                        <li>Significant changes will be communicated via the platform.</li>
                        <li>Continued use of the platform after updates implies acceptance of the new terms.</li>
                    </ul>
                </li>

            </ol>

            <p class="fs-6 mb-5 fw-normal">
                By using TrainMastas, you confirm that you have read, understood, and agreed to these Terms and Conditions.
                For support or questions, contact us at <a href="mailto:support@trainmastas.com">support@trainmastas.com</a>.
            </p>
        </div>
    </div>




    <!-- -------------------------------------------------------------------
-------------------------Let's Build It----------------------------------------------
------------------------------------------------------------------------>


    <?php
    include "footer.php"
    ?>
    <!-- Endfooter -->

</body>

</html>