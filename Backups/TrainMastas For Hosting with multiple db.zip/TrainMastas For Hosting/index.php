<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="32x32" href="./image/logo.png">

    <script src="js/jquery.js"></script>
    <script src="js/session_checker.js"></script>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/owl.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script src="js/bootstrap.js"></script>
    <title>Home - TraiMastas</title>
    <style>
        .bouncing-image {
            animation: bounce 2s infinite;
            /* 2 seconds duration */
        }

        @keyframes bounce {

            0%,
            100% {
                transform: translateY(0);
                /* Original position */
            }

            50% {
                transform: translateY(20px);
                /* Move up by 20px */
            }
        }

        .scroll-animation {
            opacity: 0;
            transform: translateY(50px);
            transition: opacity 0.6s, transform 0.6s;
        }

        .scroll-animation.animate {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>

<body>

    <?php
    include 'navbar.php';
    ?>
    <!--------------------------------------------------------------------------------------------
                                            Hero
    ---------------------------------------------------------------------------------------------->
    <section>
        <header class="container-fluid pt-navbar">
            <div class="row mx-md-4">
                <div class="col-12 col-md-6 d-flex flex-column">
                    <div class="my-auto">
                        <h1 class="fs-2">Your All-in-One Platform for YouTube-Based Courses</h1>
                        <p class="my-3 my-md-4">Connect with passionate instructors and a thriving learning community. Access high-quality YouTube content transformed into structured courses, complete with direct communication with course creators.</p>
                        <div class="my-3 my-md-5 visitor-elements">
                            <a href="signup.php" class="btn btn-outline-success rounded-0">Get Started</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 mt-3 mt-md-0 text-center">
                    <img src="image/cover.png" alt="TrainMatas" class="bouncing-image" style="width:95%; height:360px; object-fit:cover;">
                </div>
            </div>
        </header>
    </section>

    <!--------------------------------------------------------------------------------------------
                                           End Of Hero
    ---------------------------------------------------------------------------------------------->


    <!--------------------------------------------------------------------------------------------
                                            Courses
    ---------------------------------------------------------------------------------------------->
    <section class="scroll-animation">
        <div class=" mt-5" id="course-carousel-section">
            <h2 class="text-center fs-4 mb-0 mx-2">Your Journey to Mastery Begins Here</h2>
            <p class="text-center text-muted mt-1 pt-0 mx-2">Discover, learn, and grow with our diverse selection of courses designed to elevate your skills.</p>
            <div class="container mt-4">
                <div class="row">

                    <div class="col-lg-12">
                        <div class="owl-service-item owl-carousel project" id="course-container">

                        </div>
                    </div>

                    <!-------------------------------------------------------------------------------------------------
                        ------------------------------------------- Loader ---------------------------------------------
                        --------------------------------------------------------------------------------------------------->
                    <div class="row" id="course-loader">
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-2">
                            <div style="text-decoration: none;height:450px" class="item d-grid border rounded mx-2 shadow text-black">
                                <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:200px">
                                </div>
                                <div class="px-3 px-lg-4 mt-2">
                                    <h4 class="fs-6 my-1" style="word-wrap: break-word; word-break: break-all;">
                                        <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:70px">
                                        </div>
                                    </h4>
                                    <p class="text-muted fs-7  fw-semibold my-0 py-1">
                                    <div class="card-img-top spinner w-50 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                    <div class="d-flex my-1">
                                        <div class="card-img-top spinner w-75 my-0" role="status" style="padding-bottom:30px">
                                        </div>
                                    </div>
                                    <p class="p-free p-price pb-0 fw-bold fs-7 pt-1">
                                    <div class="card-img-top spinner w-25 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-none d-sm-grid my-2">
                            <div style="text-decoration: none;height:450px" class="item d-grid border rounded mx-2 shadow text-black">
                                <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:200px">
                                </div>
                                <div class="px-3 px-lg-4 mt-2">
                                    <h4 class="fs-6 my-1" style="word-wrap: break-word; word-break: break-all;">
                                        <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:70px">
                                        </div>
                                    </h4>
                                    <p class="text-muted fs-7  fw-semibold my-0 py-1">
                                    <div class="card-img-top spinner w-50 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                    <div class="d-flex my-1">
                                        <div class="card-img-top spinner w-75 my-0" role="status" style="padding-bottom:30px">
                                        </div>
                                    </div>
                                    <p class="p-free p-price pb-0 fw-bold fs-7 pt-1">
                                    <div class="card-img-top spinner w-25 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-none d-md-grid my-2">
                            <div style="text-decoration: none;height:450px" class="item d-grid border rounded mx-2 shadow text-black">
                                <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:200px">
                                </div>
                                <div class="px-3 px-lg-4 mt-2">
                                    <h4 class="fs-6 my-1" style="word-wrap: break-word; word-break: break-all;">
                                        <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:70px">
                                        </div>
                                    </h4>
                                    <p class="text-muted fs-7  fw-semibold my-0 py-1">
                                    <div class="card-img-top spinner w-50 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                    <div class="d-flex my-1">
                                        <div class="card-img-top spinner w-75 my-0" role="status" style="padding-bottom:30px">
                                        </div>
                                    </div>
                                    <p class="p-free p-price pb-0 fw-bold fs-7 pt-1">
                                    <div class="card-img-top spinner w-25 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-none d-lg-grid my-2">
                            <div style="text-decoration: none;height:450px" class="item d-grid border rounded mx-2 shadow text-black">
                                <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:200px">
                                </div>
                                <div class="px-3 px-lg-4 mt-2">
                                    <h4 class="fs-6 my-1" style="word-wrap: break-word; word-break: break-all;">
                                        <div class="card-img-top spinner w-100 my-0" role="status" style="padding-bottom:70px">
                                        </div>
                                    </h4>
                                    <p class="text-muted fs-7  fw-semibold my-0 py-1">
                                    <div class="card-img-top spinner w-50 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                    <div class="d-flex my-1">
                                        <div class="card-img-top spinner w-75 my-0" role="status" style="padding-bottom:30px">
                                        </div>
                                    </div>
                                    <p class="p-free p-price pb-0 fw-bold fs-7 pt-1">
                                    <div class="card-img-top spinner w-25 my-0" role="status" style="padding-bottom:30px">
                                    </div>
                                    </p>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!-------------------------------------------------------------------------------------------------
                ------------------------------------------- End Loader ---------------------------------------------
                --------------------------------------------------------------------------------------------------->
                </div>
            </div>
        </div>
    </section>

    <!--------------------------------------------------------------------------------------------
                                           End Of Courses
    ---------------------------------------------------------------------------------------------->

    <!--------------------------------------------------------------------------------------------
                                            Learners Feedback
    ---------------------------------------------------------------------------------------------->
    <section class="scroll-animation">
        <div class=" mt-5">
            <h2 class="text-center fs-4 mb-0 mx-2">Hear from Our Learners</h2>
            <p class="text-center text-muted mt-1 pt-0 mx-2">Insightful feedback from those who have unlocked new skills and opportunities with us.</p>
            <div class="container mt-4">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="students owl-carousel project">
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:300px">
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">The way TrainMastas organizes YouTube videos into structured courses is brilliant! It feels like I'm getting a curated learning experience, with all the important points highlighted. The descriptions for each module are super helpful too.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Sarah Johnson</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:300px">
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">I love how TrainMastas uses YouTube content to create comprehensive courses. It's like having the best of YouTube with a clear learning path. The instructors make complex topics easy to understand, and I appreciate the added context and summaries.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">David Lee</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:300px">
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">TrainMastas made learning so accessible! The courses are well-structured, and the YouTube videos are integrated seamlessly. It's great to have all the information laid out in a way that's easy to follow. It's helped me grasp concepts I struggled with before.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Michael Nguyen</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:300px">
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">The platform's unique approach of using YouTube videos for courses is genius. It's like having a personal tutor guiding me through the best educational content on the internet. The detailed module descriptions are a great touch, making it easy to focus on what's important.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Emily Martinez</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star-half-alt fa-sm"></i>
                                                <i class="far fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--------------------------------------------------------------------------------------------
                                           End Of Learners Feedback
    ---------------------------------------------------------------------------------------------->

    <!--------------------------------------------------------------------------------------------
                                            Course Category 
    ---------------------------------------------------------------------------------------------->
    <section class="scroll-animation">
        <div class=" mt-5 py-5 shadow">
            <h2 class="text-center fs-4 mb-0 mx-2">Find the Perfect Course to Match Your Learning Goals</h2>
            <p class="text-center text-muted mt-1 pt-0 mx-2">Browse through our curated categories to discover courses designed to enhance your skills and knowledge across various fields.</p>
            <div class="container mt-4">
                <div class="text-center">
                    <a href="courses.php" class="btn btn-outline-success rounded-0">Explore Courses</a>
                </div>

            </div>
        </div>
    </section>
    <!--------------------------------------------------------------------------------------------
                                           End Of Category
    ---------------------------------------------------------------------------------------------->


    <!--------------------------------------------------------------------------------------------
                                            Instructors Feedback
    ---------------------------------------------------------------------------------------------->
    <section class="scroll-animation">
        <div class=" mt-5 mb-5">
            <h2 class="text-center fs-4 mb-0 mx-2">Insights from Our Course Creators</h2>
            <p class="text-center text-muted mt-1 pt-0 mx-2">Discover what our expert creators have to say about shaping impactful learning experiences.</p>
            <div class="container mt-4">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="students owl-carousel project" id="course-container">
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/Founder_and_CEO_of_TrainMastas.png" alt="Founder and CEO of TrainMastas" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">As Founder and CEO of TrainMastas, creating courses on our platform has been transformative. The seamless integration with YouTube allows creators to focus on high-quality content without technical challenges. TrainMastas is an innovative space for sharing knowledge and connecting with a wider audience.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Ngoupayou Habil Salim - Founder & CEO</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">5.0</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/awah.png" alt="Tchinda Awa Kenny - Course Creator & Coordinator" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">TrainMastas has given me the tools to create structured and engaging courses. The option to use YouTube videos as the foundation for my lessons has allowed me to curate the best content and present it in an accessible way. It's been a great experience sharing my expertise.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Tchinda Awa Kenne - Course Creator & Coordinator</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">5.0</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/edison.jpg" alt="Mushieh Edison - Course Creator" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">TrainMastas has given me the tools to create structured and engaging courses. The option to use YouTube videos as the foundation for my lessons has allowed me to curate the best content and present it in an accessible way. It's been a great experience sharing my expertise.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Mushieh Edison - Course Creator</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star-half-alt fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/ngonjoh.png" alt="Ngonjoh Providence - Course Creator" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">As CEO of Spektralsoft, I’m proud to have collaborated on TrainMastas' platform development. Their platform has truly transformed how we deliver structured video courses—empowering learners and creators alike. It’s fulfilling to see our content making real impact through such an intuitive tool.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Ngonjoh Providence - CEO at Spektralsoft</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">5.0</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/achille.jpg" alt="TAMNGWAH ACHILLE NDI - Course Creator" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">Creating courses with TrainMastas feels effortless and rewarding. The way it lets me organize my YouTube content into clear, guided modules has completely elevated how I teach online. Learner engagement and feedback have never been better.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">TAMNGWAH ACHILLE NDI - Course Creator</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">5.0</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item d-grid border rounded text-black">
                                <div class="p-4 d-flex flex-column" style="height:455px">
                                    <div class="text-center mb-3">
                                        <img src="image/malaloum.png" alt="Malaloum Djou Mireille - Course Creator" class="rounded-circle mx-auto" style="width:140px; height:140px; object-fit:cover">
                                    </div>
                                    <svg class="quote-icon opening" xmlns="http://www.w3.org/2000/svg" fill="#000000" width="20px" height="20px" viewBox="0 0 24 24">
                                        <path d="M3.691 6.292C5.094 4.771 7.217 4 10 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 6.925 10H10a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2H3a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789zM20 20h-6a1 1 0 0 1-1-1v-5l.003-2.919c-.009-.111-.199-2.741 1.688-4.789C16.094 4.771 18.217 4 21 4h1v2.819l-.804.161c-1.37.274-2.323.813-2.833 1.604A2.902 2.902 0 0 0 17.925 10H21a1 1 0 0 1 1 1v7c0 1.103-.897 2-2 2z"></path>
                                    </svg>
                                    <h4 class="fs-6 my-2 fw-normal">As CTO of Spektralsoft, I’ve been impressed by TrainMastas’ technical vision. Collaborating on its development was a great experience. The platform’s smart structure and smooth delivery make it a powerful tool for scalable, engaging online learning.</h4>
                                    <div class="w-100 mt-auto">
                                        <p class="text-muted fs-7  fw-semibold my-0 py-1 ">Malaloum Djou Mireille - Course Creator & CTO at Spektralsoft</p>
                                        <div class="d-flex mb-1 ">
                                            <span class="text-muted me-1 fs-6 fw-semibold">4.5</span>
                                            <span class="text-success">
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star fa-sm"></i>
                                                <i class="fas fa-star-half-alt fa-sm"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!--------------------------------------------------------------------------------------------
                                           End Of Instructors Feedback
    ---------------------------------------------------------------------------------------------->





    <!--------------------------------------------------------------------------------------------
                                          Become
    ---------------------------------------------------------------------------------------------->
    <section class="scroll-animation">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 mb-4 mb-lg-0 text-center">
                    <img src="image/become_instructor.png" alt="Become Instructor" class="" style="width:90%;height:400px;object-fit:cover;">
                </div>
                <div class="col-12 col-lg-6 text-center text-lg-start d-flex">
                    <div class="my-auto">
                        <h3 class="fs-3">Become A Course Creators</h3>
                        <div class="my-4 fs-5">Join a community of innovative course creators who are transforming their knowledge into engaging online learning experiences</div>
                        <a href="#" class="btn btn-outline-success rounded-0 visitor-elements">Get Started</a>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--------------------------------------------------------------------------------------------
                                           End Of Become Course Creator
    ---------------------------------------------------------------------------------------------->


    <?php
    include "footer.php";
    ?>

    </script>
    <script src="js/owl-carousel.js"></script>

    <script>
        $(document).ready(function() {

            $('.students').owlCarousel({
                items: 3,
                loop: true,
                dots: true,
                nav: true,
                margin: 15,
                autoplayTimeout: 5000, // Set your desired autoplay speed
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1,
                        autoplay: true // Enable autoplay for small screens
                    },
                    700: {
                        items: 2,
                        autoplay: true // Disable autoplay for medium screens
                    },
                    1200: {
                        items: 3,
                        autoplay: false // Disable autoplay for large screens
                    }
                }
            });
        })
    </script>

    <script>
        let lastScrollY = 0;

        function revealSections() {
            const sections = document.querySelectorAll('.scroll-animation');
            const currentScrollY = window.scrollY;

            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.offsetHeight;
                const windowHeight = window.innerHeight;

                // Check if the section is within the viewport
                if (sectionTop < currentScrollY + windowHeight * 0.8 && sectionTop + sectionHeight > currentScrollY) {
                    section.classList.add('animate');
                } else {
                    section.classList.remove('animate');
                }
            });
            lastScrollY = currentScrollY;
        }

        window.addEventListener('scroll', revealSections);
        window.addEventListener('load', revealSections);
    </script>
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $("#items").removeClass("d-none");
                $("#loader").addClass("d-none");
            }, 1000)
        })
        $(".home").addClass("active2");
    </script>

    <script src="js/get_these_course.js"> </script>
</body>

</html>