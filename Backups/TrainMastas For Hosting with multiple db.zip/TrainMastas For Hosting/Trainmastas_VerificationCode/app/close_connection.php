<?php
$course_conn->close();
$user_conn->close();
$payment_conn->close();
