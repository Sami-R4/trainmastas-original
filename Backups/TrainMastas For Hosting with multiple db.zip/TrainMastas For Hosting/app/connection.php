<?php
// Create connection
$user_conn = new mysqli('localhost', 'root', '', 'trainmastas_users');
$course_conn = new mysqli('localhost', 'root', '', 'trainmastas_courses');
$payment_conn = new mysqli('localhost', 'root', '', 'trainmastas_payments');

// $user_conn = new mysqli('localhost', 'u534990407_ngoupayou', 'Afriquemedia@12', 'u534990407_trainmastas_us');
// $course_conn = new mysqli('localhost', 'u534990407_ngoupayouhabil', 'Afriquemedia@12', 'u534990407_trainmastas_co');
// $payment_conn = new mysqli('localhost', 'u534990407_ngoupayou1', 'Afriquemedia@12', 'u534990407_trainmastas_pa');
