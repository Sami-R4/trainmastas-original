$(document).ready(function () {

    /////////////////////////////////////////////////////////////////
    //                          Remove /$$**$$/
    /////////////////////////////////////////////////////////////////
    function replacePatternWithSpace(content) {
        // Replace all occurrences of /$$**$$/ with space
        var replacedContent = content.replace(/\/\$\$\*\*\$\$\//g, " ");

        // Return the output which is an html tag
        return replacedContent;
    }
    /////////////////////////////////////////////////////////////////
    //                          Create btns
    /////////////////////////////////////////////////////////////////
    function create_pages_btn(PageNbr, id, totalPages) {
        let btns = ""; // Holds the pagination buttons
        const prev = "#prevBtn" + id; // ID for the previous button
        const next = "#nextBtn" + id; // ID for the next button
        const pagination = "#pagination-Btn" + id; // ID for the pagination container

        // Clear existing pagination buttons
        $(pagination).empty();

        // Determine the range of buttons to display
        let startPage = Math.max(1, PageNbr - 1); // Start from the previous page (if it exists)
        let endPage = Math.min(totalPages, PageNbr + 1); // End at the next page (if it exists)

        // Ensure we always display 3 buttons if possible
        if (PageNbr == 1 && totalPages > 1) {
            // First page: Show the first 3 pages if available
            endPage = Math.min(totalPages, 3);
        } else if (PageNbr == totalPages && totalPages > 1) {
            // Last page: Show the last 3 pages if available
            startPage = Math.max(1, totalPages - 2);
        } else if (totalPages > 1) {
            // Middle page: Adjust start and end to ensure 3 buttons
            startPage = Math.max(1, PageNbr - 1);
            endPage = Math.min(totalPages, PageNbr + 1);
        }

        // Generate pagination buttons
        var temp_counter = 0;

        for (let i = startPage; i <= endPage; i++) {
            var activeClass = i == PageNbr ? "custom-button" : ""; // Add the 'active' class to the current page
            btns += `<button class="btn custom-btn pageBtn ${activeClass} mx-1">${i}</button>`;
            temp_counter++;
            if (temp_counter == 3) {
                break;
            }
        }

        // Add buttons to the pagination container
        $(pagination).append(btns);

        // Manage the previous button state
        if (PageNbr == 1) {
            $(prev).addClass("disabled");
        } else {
            $(prev).removeClass("disabled");
        }

        // Manage the next button state
        if (PageNbr == totalPages) {
            $(next).addClass("disabled");
        } else {
            $(next).removeClass("disabled");
        }
    }
    /////////////////////////////////////////////////////////////////
    //                Give Stars
    /////////////////////////////////////////////////////////////////
    function giveStars(num) {
        var full_star = `<i class="fas fa-star fa-sm"></i>`,
            empty_star = `<i class="far fa-star fa-sm"></i>`,
            half_star = `<i class="fas fa-star-half-alt fa-sm"></i>`,
            stars = ``,
            even,
            rem,
            Feven;
        if (num % 2 == 0) {
            even = num / 2;
            Feven = Math.ceil(num / 2);
            rem = 0;
        } else {
            even = (num - 1) / 2;
            Feven = Math.ceil(num / 2);
            rem = 1;
        }
        for (var i = 1; i <= even; i++) {
            stars = stars + full_star;
        }
        if (rem == 1) {
            stars = stars + half_star;
        }
        if (Feven <= 4) {
            for (var i = Feven; i < 5; i++) {
                if (num != 9 || num != 10) {
                    stars = stars + empty_star;
                }
            }
        }
        return stars;
    }

    /////////////////////////////////////////////////////////////////
    //                            Capitalizer
    /////////////////////////////////////////////////////////////////
    var max, totalPages;
   /////////////////////////////////////////////////////////////////
    //                            Capitalizer
    /////////////////////////////////////////////////////////////////
    function capitalizeFirstLetter(statement) {  
        // Escape quotes to prevent conflicts in HTML  
        function escapeQuotes(value) {  
            return value.replace(/"/g, '&quot;').replace(/'/g, '&#39;');  
        }  
    
        // Escape the input statement  
        const escapedStatement = escapeQuotes(statement);  
        var words = escapedStatement.split(" ");  
        var capitalizedWords = [];  
    
        for (var i = 0; i < words.length; i++) {  
            var word = words[i];  
            if (word.length > 0) {  
                // Capitalize the first letter if it's an alphabetical character  
                if (/^[a-zA-Z]/.test(word.charAt(0))) {  
                    word = word.charAt(0).toUpperCase() + word.slice(1);  
                }  
            }  
            capitalizedWords.push(word);  
        }  
    
        return capitalizedWords.join(" ");  
    }  

    /////////////////////////////////////////////////////////////////
    //                 Capitalizer of first letter of phrase
    /////////////////////////////////////////////////////////////////
    function capitalizeFirstLetterOfPhrase(statement) {  
        // Escape quotes to prevent conflicts in HTML  
        function escapeQuotes(value) {  
            return value.replace(/"/g, '&quot;').replace(/'/g, '&#39;');  
        }  
        // Escape the input statement  
        const escapedStatement = escapeQuotes(statement);  
        // Capitalize the first letter if the first character is a letter  
        if (escapedStatement.length > 0) {  
            const firstChar = escapedStatement.charAt(0);  
            // Check if the first character is a letter (using regex)  
            if (/^[a-zA-Z]/.test(firstChar)) {  
                return escapedStatement.charAt(0).toUpperCase() + escapedStatement.slice(1);  
            }  
        }  
        // Return the escaped statement unchanged if no capitalization is applied or if it's empty  
        return escapedStatement;  
    }  
    /////////////////////////////////////////////////////////////////
    //                Replace Space with underscore
    /////////////////////////////////////////////////////////////////
    function replaceSpaceWithUnderscore(text) {
        return text.replace(" ", "_");
    }
    /////////////////////////////////////////////////////////////////
    //                Format Currency
    /////////////////////////////////////////////////////////////////
    function formatCurrency(value) {
        return '$' + parseFloat(value).toFixed(2);
    }
    /////////////////////////////////////////////////////////////////
    //               Group Numbers
    /////////////////////////////////////////////////////////////////
    function groupNumber(num) {
        if (num < 1000) {
            return num.toString();
        } else if (num < 10000) {
            return Math.floor(num / 1000) + 'k';
        } else if (num < 100000) {
            return Math.floor(num / 1000) + 'K';
        } else if (num < 1000000) {
            return Math.floor(num / 1000) + 'K';
        } else if (num < 10000000) {
            return (num / 1000000).toFixed(1) + 'M'; // One decimal place  
        } else if (num < 1000000000) {
            return (num / 1000000).toFixed(1) + 'M'; // One decimal place  
        } else if (num < 10000000000) {
            return (num / 1000000000).toFixed(1) + 'B'; // One decimal place  
        } else {
            return (num / 1000000000).toFixed(1) + 'B'; // One decimal place  
        }
    }

    ////////////////////////////////////////////////////////////////////
    ///////           Payment Course Navigation Bnts          ///////
    ////////////////////////////////////////////////////////////////////
    // operations for prevBtn 
    $("#prevBtn").on("click", function () {
        if (currentPage > 1) {
            $(this).addClass("disabled");
            $("#prevBtn").addClass("disabled");
            $("#nextBtn").addClass("disabled");
            var containerTop = $("#saved_id").offset().top;
            $("html, body").scrollTop(containerTop);
            currentPage--;

            $("#pagination-Btn .pageBtn").removeClass("custom-button");
            $(`#pagination-Btn .pageBtn:contains('${currentPage}')`).addClass("custom-button");

            setTimeout(function () {
                $("#course-container").addClass("d-none");
                $("#course-loader").removeClass("d-none");
                getthem(currentPage, type, purpose);
            }, 800);
        }
    });

    // Operations for nextBtn for payment courses
    $("#nextBtn").on("click", function () {
        if (currentPage < totalPages) {
            $(this).addClass("disabled");
            var containerTop = $("#saved_id").offset().top;
            $("html, body").scrollTop(containerTop);
            currentPage++;

            $("#pagination-Btn .pageBtn").removeClass("custom-button");
            $(`#pagination-Btn .pageBtn:contains('${currentPage}')`).addClass("custom-button");

            setTimeout(function () {
                $("#course-container").addClass("d-none");
                $("#course-loader").removeClass("d-none");
                getthem(currentPage, type, purpose);
            }, 800);
        }
    });
    // operations for in between prevBtn and nextBtn
    $("#pagination-Btn").on("click", ".pageBtn", function () {
        currentPage = $(this).text();
        $("#pagination-Btn .pageBtn").removeClass("custom-button");
        $(this).addClass("custom-button");
        var containerTop = $("#saved_id").offset().top;
        $("html, body").scrollTop(containerTop);
        setTimeout(function () {
            $("#course-container").addClass("d-none");
            $("#course-loader").removeClass("d-none");
            getthem(currentPage, type, purpose);
        }, 800);
    });

    /////////////////////////////////////////////////////////////////
    //                  TO put Years Ago
    /////////////////////////////////////////////////////////////////
    function timeAgo(date, now) {
        var now = new Date(now);
        let secondsPast = (now.getTime() - new Date(date).getTime()) / 1000;
        if (secondsPast < 60) {
            return `${Math.floor(secondsPast)}s ago`;
        }
        if (secondsPast < 3600) {
            return `${Math.floor(secondsPast / 60)}m ago`;
        }
        if (secondsPast < 86400) {
            return `${Math.floor(secondsPast / 3600)}h ago`;
        }
        if (secondsPast < 604800) {
            return `${Math.floor(secondsPast / 86400)}d ago`;
        }
        if (secondsPast < 2592000) {
            return `${Math.floor(secondsPast / 604800)}w ago`;
        }
        if (secondsPast < 31536000) {
            return `${Math.floor(secondsPast / 2592000)}m ago`;
        }
        if (secondsPast < 3153600000) {
            return `${Math.floor(secondsPast / 31536000)}y ago`;
        }
        return `${Math.floor(secondsPast / 3153600000)}00y ago`; // handling for 100 years and beyond
    }

    /////////////////////////////////////////////////////////////////
    //                Get Courses from specific type
    /////////////////////////////////////////////////////////////////
    function getthem(page, type, purpose) {
        $("#course-loader").removeClass("d-none");
        $("#course-container").addClass("d-none");
        var limit = 12;

        $.ajax({
            url: "app/course_process.php",
            method: "POST",
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('access_token')  // Send the stored token
            },
            data: { page: page, limit: limit, type: type, purpose: purpose },
            dataType: "json",
            success: function (response) {
                var elements = "";

                setTimeout(function () {
                    if (response.state === "success") {
                        var numCourses = response.total;
                        elements = ``;
                        var cost;
                        for (var i = 0; i < response.Courses.length; i++) {
                            cost = "Free";
                            if (response.Courses[i].Cost != 0) {
                                cost = formatCurrency(response.Courses[i].Cost)
                            }
                            $("#showing-span").text(numCourses);
                            $("#showing-div").removeClass("d-none");
                            var temp_class = response.Courses[i].Total_Rates <= 0 || Number(response.Courses[i].Rate) <= 0 ? "d-none" : "";
                            var element = `<div class="col-12 col-sm-6 col-lg-4 col-xl-3 my-2">
                                    <a href="displaycourse.php?v=`+ response.Courses[i].course_ID + `" style="text-decoration: none;height:450px" class="item d-grid border rounded card-h-effect text-black">
                                        <img style="width:100%; height:200px; object-fit:cover" src="covers/${response.Courses[i].Cover_image ? response.Courses[i].Cover_image : "default-cover.jpg"}" alt="` + capitalizeFirstLetter(response.Courses[i].Title) + `">
                                        <div class="px-3 px-lg-4">
                                            <h4 class="fs-6 my-1" style="word-wrap: break-word; word-break: break-all;">`+ capitalizeFirstLetter(response.Courses[i].Title) + `</h4>
                                            <p class="text-muted fs-7  fw-semibold my-0 py-1 mt-2">
                                            <img src="${response.Courses[i].Creator_image ? "profile/" + response.Courses[i].Creator_image : "image/default-profile.png"}" alt="${capitalizeFirstLetter(response.Courses[i].Creator_Name)}" class="me-1 rounded-circle" style="width:30px;height:30px;object-fit:cover;">
                                           `+ capitalizeFirstLetter(response.Courses[i].Creator_Name) + `</p>
                                            <div class="d-flex my-1 `+ temp_class + `">
                                                <span class="text-muted me-1 fs-6 fw-semibold ">`+ response.Courses[i].Rate + `</span>
                                                <span class="text-success ">
                                                    ` +
                                giveStars(response.Courses[i].Rate) +
                                `
                                                </span>
                                                <span class="text-muted ms-1 fs-7 fw-semibold">(`+ groupNumber(response.Courses[i].Total_Rates) + `)</span>
                                            </div>
                                                <p class="p-free p-price pb-0 fw-bold fs-7 pt-1">`+ cost + `</p>
                                            <div class="d-flex justify-content-between">
                                                <p class="text-muted pb-0 fs-7 pt-1">`+ timeAgo(response.Courses[i].Date, response.Courses[0].Current_Date) + `</p>
                                                <p class="text-muted pb-0 fs-7 pt-1">${response.Courses[i].Num_test != 0 ? 'With Certificate' : 'No Certificate'}</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>`;
                            elements = elements + element;
                        }
                        totalPages = Math.ceil(response.total / 12); // Assuming response.total is a valid numeric value
                        max = (currentPage - 1) * 12 + response.total;
                        min = (currentPage - 1) * 12;
                        if (response.total > 12) {
                            create_pages_btn(currentPage, "", totalPages);
                            $("#btn-container").removeClass("d-none");
                        }
                    } else {
                        $("#showing-span").text("0");
                        elements = `<div class="col-12"><div class="rounded border p-4 mt-lg-0 mb-5 mb-md-0">No course Found</div></div>`;
                    }

                    $("#course-loader").addClass("d-none");
                    $("#course-container").removeClass("d-none").empty().append(elements);
                }, 1000);
            },
        });
    }

    var item_to_search = "";
    var currentPage = 1;
    var type = "all";
    var purpose;
    if (localStorage.getItem('search') !== null) {
        purpose = "search";
        type = localStorage.getItem('search');
        item_to_search = type;
        localStorage.removeItem('search');

    } else {
        purpose = "getItems";
    }
    getthem(currentPage, type, purpose);



    // course page search box operations
    $("#search_box").keypress(function (e) {
        if (e.which == 13) {
            // 13 is the keycode for Enter key
            e.preventDefault();
            $("#course-loader").removeClass("d-none");
            $('.form-check-input').prop('checked', false);
            updateURL($("#search_box"));
        }
        // Update URL
        function updateURL(val) {
            $("#course-loader").removeClass("d-none");
            $("#course-container").empty();
            $("#btn-container").addClass("d-none");
            purpose = "search";
            var newURL = "?page=" + 1 + "";
            history.pushState({}, "", newURL);
            type = val.val();
            item_to_search = type;
            currentPage = 1;
            getthem(1, type, purpose);
            val.val("");
            // val.autocomplete("close");
        }
    });

    // Search operations
    var timeoutId,
        period = "",
        val_type = "",
        category = [];

    // Search using the category form 
    $(".form-check-input").click(function () {
        // var id = $(this).find(".form-check-input"),
        var id = $(this),
            dataType;
        dataType = id.data("type");
        clearTimeout(timeoutId);
        if ($(this).prop("checked") == true) {
            if (dataType == "period") {
                period = id.val();
            } else if (dataType == "type") {
                val_type = id.val();
            } else if (dataType == "category") {
                category.push(id.val());
            }
        } else {
            if (dataType == "period") {
                period = "";
            } else if (dataType == "type") {
                val_type = "";
            } else if (dataType == "category") {
                category.splice(category.indexOf(id.val()), 1);
            }
        }
        let dataToSend = {
            "period": period,
            "course_type": val_type,
            "category": category,
            "search": item_to_search
        };

        console.log(dataToSend);
        timeoutId = setTimeout(function () {
            currentPage = 1;
            type = dataToSend;
            purpose = "filter";
            getthem(currentPage, dataToSend, "filter");

        }, 30);
    });
    $('.period-checkbox').change(function () {
        $('.period-checkbox').not(this).prop('checked', false);
    });
    $('.type-checkbox').change(function () {
        $('.type-checkbox').not(this).prop('checked', false);
    });
});
